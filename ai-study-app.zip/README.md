# AI 학습 분석 & 의견 게시판 앱

## 프로젝트 구성
- `index.html`: 프론트엔드 웹 UI 및 Firebase Firestore 연동
- `api/generate.js`: Vercel Serverless Function (Gemini API 호출)
- `package.json`: 프로젝트 의존성 설정

## 설정 안내
1. Firebase Console (Firestore Database -> Rules)에서 보안 규칙을 설정하세요:
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /comments/{document} {
         allow read, write: if true;
       }
     }
   }
   ```
2. Vercel 배포 시 환경변수 `GEMINI_API_KEY`를 설정해주세요.
